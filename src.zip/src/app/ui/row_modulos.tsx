import AulaCard from "./quad_aula";

export default function ModuloAulas({ modulo }) {
    return (
        <div className="bg-sky-400 p-4 rounded-lg shadow-md flex gap-4 overflow-x-auto">
            {modulo.aulas.length > 0 ? (
                modulo.aulas.map((aula) => (
                    <AulaCard key={aula.id_aula} aula={aula} />
                ))
            ) : (
                <p className="text-white text-lg">Nenhuma aula disponível</p>
            )}
        </div>
    );
}
