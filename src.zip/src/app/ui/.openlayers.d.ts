declare const OpenLayers: any;

