import Link from 'next/link';

const statusColors = {
    disponivel: {
        header: 'bg-yellow-700',
        body: 'bg-yellow-400',
    },
    feita: {
        header: 'bg-green-700',
        body: 'bg-green-400',
    },
    indisponivel: {
        header: 'bg-gray-700',
        body: 'bg-gray-400',
    },
};

const getStatus = (completada) => {
    if (completada === 1) return 'feita';
    if (completada === 0) return 'disponivel';
    return 'indisponivel';
};

export default function QuadAula({ aula }) {
    const status = getStatus(aula.completada);
    const colors = statusColors[status];

    return (
        <div className="rounded-lg shadow-md w-64">
            <div className={`p-4 text-white font-bold text-lg rounded-t-lg ${colors.header}`}>
                {aula.nome_aula}
            </div>

            <Link href={`/aula/detalhes/${aula.id_aula}`}>
                <div className={`p-6 text-center text-black font-semibold cursor-pointer rounded-b-lg ${colors.body}`}>
                    {status === 'disponivel' && 'Disponível para fazer'}
                    {status === 'feita' && 'Feita'}
                    {status === 'indisponivel' && 'Indisponível'}
                </div>
            </Link>
        </div>
    );
}

