"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import BarraLatEsq from "@/app/ui/barralatesq";
import BarraLatDir from "@/app/ui/barralatdir";
import ModuloAulas from "@/app/ui/row_modulos";

export default function AlunoPage() {
    const [curso, setCurso] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(false);

    useEffect(() => {
        const fetchCurso = async () => {
            try {
                const response = await fetch("/api/cursos");
                if (response.ok) {
                    const data = await response.json();
                    setCurso(data);
                } else {
                    throw new Error("Erro ao buscar curso");
                }
            } catch (error) {
                console.error("Erro na requisição:", error);
                setError(true);
            } finally {
                setLoading(false);
            }
        };

        fetchCurso();
    }, []);

    if (loading) {
        return (
            <div className="text-center mt-20 text-xl text-gray-700">
                Carregando curso...
            </div>
        );
    }

    if (error || !curso) {
        return (
            <div className="text-center mt-20 text-xl text-red-600">
                Erro ao carregar o curso.
            </div>
        );
    }

    return (
        <div className="flex">
            <BarraLatEsq />
            <div className="p-8 bg-sky-200 min-h-screen flex flex-col items-start flex-1">
                <h1 className="text-3xl font-bold text-gray-800 mb-6">
                    {curso.nome_curso || "Curso não encontrado"}
                </h1>

                <div className="space-y-6 w-full">
                    {curso.modulos && curso.modulos.length > 0 ? (
                        curso.modulos.map((modulo: any) => (
                            <div key={modulo.id_modulo} className="w-full">
                                <h2 className="text-2xl font-semibold text-gray-700 mb-2">
                                    Módulo {modulo.id_modulo}: {modulo.tipo_modulo}
                                </h2>
                                <ModuloAulas modulo={modulo} />
                            </div>
                        ))
                    ) : (
                        <p className="text-gray-700 text-lg">Nenhum módulo disponível</p>
                    )}
                </div>
            </div>
            <BarraLatDir />
        </div>
    );
}

